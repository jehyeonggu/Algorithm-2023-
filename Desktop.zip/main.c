#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>  

#include "tree.h"

int main()
{
    printf("Hello World\n");

    int value = 200; //ã�� ���� ��
    Node* find_value;

    Node* root = makeTree();
    printTree(root);

    getch();  

    printNode(root);
    find_value = findNode(root, value);

    printf("\n ã������ value: %d, �ش��ϴ� �ּ�: %p \n", find_value->value, find_value);
    root = insertLeftNode(root, createNode(1000));
    printTree(root);
    return 0;
}
