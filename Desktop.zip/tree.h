typedef struct Node
{
	int value;
	struct Node* left;
	struct Node* right;
} Node;

extern Node* makeTree();
extern void printTree(Node* root);
extern void pre_order(Node* root);
extern void in_order(Node* root);
extern void post_order(Node* root);
extern void printNode(Node* root);
extern Node* findNode(Node* root, int value);
extern Node* insertLeftNode(Node* where, Node* new_node);
extern Node* insertRightNode(Node* where, Node* new_node);